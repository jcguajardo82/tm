$(function() {

  $('#menu1').metisMenu();

  $('#menu2').metisMenu({
    toggle: false
  });

  $('#menu3').metisMenu();

});
